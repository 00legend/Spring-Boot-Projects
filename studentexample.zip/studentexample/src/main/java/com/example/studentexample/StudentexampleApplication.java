package com.example.studentexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentexampleApplication.class, args);
	}

}
