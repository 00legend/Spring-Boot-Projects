package com.firstexample.spring_helloworld;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringHelloworldApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringHelloworldApplication.class, args);
	}

}
