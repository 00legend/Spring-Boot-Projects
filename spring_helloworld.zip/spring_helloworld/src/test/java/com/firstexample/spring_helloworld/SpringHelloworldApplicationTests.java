package com.firstexample.spring_helloworld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHelloworldApplicationTests {

	@Test
	void contextLoads() {
	}

}
