package com.example.ecom_Product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcomProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcomProductApplication.class, args);
	}

}
