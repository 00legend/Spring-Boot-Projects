package com.example.ecom_Product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
