package com.example.ProductExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductExampleApplication.class, args);
	}

}
