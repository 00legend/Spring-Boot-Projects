package com.example.ProductExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
